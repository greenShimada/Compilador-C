main() {
	int a,b,c,aux;
	a = 550;
	b = 30;
	c = 40;
}
