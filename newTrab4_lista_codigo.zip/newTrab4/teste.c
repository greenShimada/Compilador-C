main() {
	int a,b,c,aux;
    a = read();
    b = read();
    
	if (a > b) 
		a = 20;
	else 
		a = 10;	
	println(a);		

}
